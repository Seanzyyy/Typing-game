﻿namespace typingGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.startButton = new System.Windows.Forms.Button();
            this.wordButton = new System.Windows.Forms.RadioButton();
            this.sentencesButton = new System.Windows.Forms.RadioButton();
            this.bothButton = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(49, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(244, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select game mode:";
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.exitButton.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(53, 213);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(156, 53);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // startButton
            // 
            this.startButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.startButton.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startButton.Location = new System.Drawing.Point(325, 212);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(142, 54);
            this.startButton.TabIndex = 2;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // wordButton
            // 
            this.wordButton.Font = new System.Drawing.Font("Microsoft YaHei", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wordButton.Location = new System.Drawing.Point(55, 153);
            this.wordButton.Name = "wordButton";
            this.wordButton.Size = new System.Drawing.Size(154, 40);
            this.wordButton.TabIndex = 3;
            this.wordButton.TabStop = true;
            this.wordButton.Text = "Words";
            this.wordButton.UseVisualStyleBackColor = true;
            this.wordButton.CheckedChanged += new System.EventHandler(this.wordButton_CheckedChanged);
            // 
            // sentencesButton
            // 
            this.sentencesButton.Font = new System.Drawing.Font("Microsoft YaHei", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sentencesButton.Location = new System.Drawing.Point(200, 153);
            this.sentencesButton.Name = "sentencesButton";
            this.sentencesButton.Size = new System.Drawing.Size(153, 40);
            this.sentencesButton.TabIndex = 4;
            this.sentencesButton.TabStop = true;
            this.sentencesButton.Text = "Sentences";
            this.sentencesButton.UseVisualStyleBackColor = true;
            this.sentencesButton.CheckedChanged += new System.EventHandler(this.sentencesButton_CheckedChanged);
            // 
            // bothButton
            // 
            this.bothButton.Font = new System.Drawing.Font("Microsoft YaHei", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bothButton.Location = new System.Drawing.Point(382, 153);
            this.bothButton.Name = "bothButton";
            this.bothButton.Size = new System.Drawing.Size(142, 40);
            this.bothButton.TabIndex = 5;
            this.bothButton.TabStop = true;
            this.bothButton.Text = "Both";
            this.bothButton.UseVisualStyleBackColor = true;
            this.bothButton.CheckedChanged += new System.EventHandler(this.bothButton_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(46, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(261, 42);
            this.label2.TabIndex = 6;
            this.label2.Text = "Typing Game :)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(496, 284);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bothButton);
            this.Controls.Add(this.sentencesButton);
            this.Controls.Add(this.wordButton);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.RadioButton wordButton;
        private System.Windows.Forms.RadioButton sentencesButton;
        private System.Windows.Forms.RadioButton bothButton;
        private System.Windows.Forms.Label label2;
    }
}

