﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace typingGame
{
    public partial class Form1 : Form
    {
        gameMode G;
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// When clicked, if a mode is checked, the lists are initialized and the game page is opened.
        /// if not, the user is prompted to select a mode
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void startButton_Click(object sender, EventArgs e)
        {
            if (wordButton.Checked == false && sentencesButton.Checked == false && bothButton.Checked == false)
            {
                MessageBox.Show("You have to select a mode to proceed!");
            }
            else
            {
                listsAndGameMode.initializeLists();
                Form2 f2 = new Form2();
                this.Hide();
                f2.ShowDialog();
                this.Close();
            }
        }
        /// <summary>
        /// when a radiobutton is checked, a new gameMode enum instance is created and assigned to the
        /// value of the specific mode enum.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void wordButton_CheckedChanged(object sender, EventArgs e)
        {
            if(wordButton.Checked==true) 
            { 
                G = gameMode.wordMode;
                listsAndGameMode.currentMode=(int)G;
                listsAndGameMode.timeToTypeSingleItem = 10;
            }
        }

        private void sentencesButton_CheckedChanged(object sender, EventArgs e)
        {
            if (sentencesButton.Checked==true)
            {
                G = gameMode.sentenceMode;
                listsAndGameMode.currentMode = (int)G;
                listsAndGameMode.timeToTypeSingleItem = 20;
            }
        }

        private void bothButton_CheckedChanged(object sender, EventArgs e)
        {
            if (bothButton.Checked==true)
            {
                G = gameMode.bothMode;
                listsAndGameMode.currentMode = (int)G;
                listsAndGameMode.timeToTypeSingleItem = 20;
            }
        }
    }
}
