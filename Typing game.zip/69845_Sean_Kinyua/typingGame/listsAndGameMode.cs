﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace typingGame
{
    static class listsAndGameMode
    {
        public static List<string> wordList=new List<string>();
        public static List<string> sentenceList = new List<string>();
        public static List<string> bothList = new List<string>();
        public static List<string> selectedList= new List<string>();
        public static int timeToTypeSingleItem;
        public static int currentMode;

        public static void initializeLists()
        {
            FileStream fs = new FileStream("AllWordsAndSentences.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine();
                string[] testifWord = line.Split(' ');
                if (testifWord.Length > 1)
                {
                    listsAndGameMode.sentenceList.Add(line);
                    listsAndGameMode.bothList.Add(line);
                }
                else
                {
                    listsAndGameMode.wordList.Add(line);
                    listsAndGameMode.bothList.Add(line);
                }
            }
        }

        
    }
    public enum gameMode
    {
        wordMode, bothMode, sentenceMode
    }
}
