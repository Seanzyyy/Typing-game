﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace typingGame
{
    public partial class Form2 : Form
    {
        public int j = 1;
        public Form2()
        {
            InitializeComponent();
        }
        /// <summary>
        /// when the form is loaded, if statements check what the currentMode is equal to. It
        /// then sets the label schowing what to type to the first item of the respective list.
        /// The timer is set to 10 seconds for the word mode and 20 seconds for the sentence mode.
        /// The timers are then started
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form2_Load(object sender, EventArgs e)
        {
            if(listsAndGameMode.currentMode==(int)gameMode.wordMode)
            {
                listsAndGameMode.selectedList=listsAndGameMode.wordList;
                taskLabel.Text = listsAndGameMode.wordList[0];
                typingTimer.Interval = 10000;
            }

            if (listsAndGameMode.currentMode == (int)gameMode.sentenceMode)
            {
                listsAndGameMode.selectedList = listsAndGameMode.sentenceList;
                taskLabel.Text = listsAndGameMode.sentenceList[0];
                typingTimer.Interval = 20000;
            }

            if (listsAndGameMode.currentMode == (int)gameMode.bothMode)
            {
                listsAndGameMode.selectedList = listsAndGameMode.bothList;
                taskLabel.Text = listsAndGameMode.bothList[0];
                typingTimer.Interval = 20000;
            }
            timerLabel.Text=listsAndGameMode.timeToTypeSingleItem.ToString();
            typingTimer.Enabled = true;
            countdownTimer.Enabled = true;
        }
        /// <summary>
        /// when the timer ticks, the timerLabel is reset and the item to type is changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void typingTimer_Tick(object sender, EventArgs e)
        {
            timerLabel.Text = listsAndGameMode.timeToTypeSingleItem.ToString();
            taskLabel.Text = listsAndGameMode.selectedList[j];
            j += 1;
        }
        /// <summary>
        /// timer to reduce the timerLabel by 0.1 every tenth of a second
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void countdownTimer_Tick(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(timerLabel.Text);
            x -= 0.1;
            timerLabel.Text=x.ToString();
        }
        /// <summary>
        /// checks if the text in the textbox is equal. If true, a score is added, the item to be typed
        /// is changed and timerLabel is reset
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void answerTb_TextChanged(object sender, EventArgs e)
        {
            if(answerTb.Text==taskLabel.Text)
            {
                int x= Convert.ToInt32(scoreLabel.Text);
                x += 1;
                scoreLabel.Text=x.ToString();

                timerLabel.Text = listsAndGameMode.timeToTypeSingleItem.ToString();

                taskLabel.Text = listsAndGameMode.selectedList[j];
                j += 1;

                answerTb.Clear();

            }
        }
        /// <summary>
        /// when clicked, the user finishes the round and user's score is shown. The game is stopped
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        { 
            countdownTimer.Stop();
            typingTimer.Stop();
            MessageBox.Show($"You have ended the round!\nScore: {scoreLabel.Text} ");
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
            this.Close();
        }
    }
}
